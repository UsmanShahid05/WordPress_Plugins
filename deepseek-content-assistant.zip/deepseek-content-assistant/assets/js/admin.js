jQuery(document).ready(function($) {
    // Only run on the "Generate Content" tab
    if (window.location.href.indexOf('tab=settings') === -1) {
        $('#generate-content').on('click', function() {
            const prompt = $('#deepseek-prompt').val();
            const nonce = deepseek_vars.nonce;

            $('#deepseek-output').html('<div class="spinner is-active"></div> Generating...');

            $.post(
                deepseek_vars.ajax_url,
                {
                    action: 'deepseek_generate_content',
                    prompt: prompt,
                    nonce: nonce
                },
                function(response) {
                    $('#deepseek-output').html(response.data);
                }
            ).fail(function(error) {
                $('#deepseek-output').html('Error: ' + error.responseText);
            });
        });
    }
});