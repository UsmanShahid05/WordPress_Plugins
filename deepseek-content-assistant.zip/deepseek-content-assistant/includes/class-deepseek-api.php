<?php
class DeepSeek_API {
    private $api_key;
    private $api_url;

    public function __construct($api_key) {
        $this->api_key = $api_key;
        $this->api_url = 'https://api.deepseek.com/v1/chat/completions'; // Update if needed
    }

    public function generate_content($prompt, $max_tokens = 500) {
        $headers = array(
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $this->api_key,
        );

        $body = array(
            'model' => 'deepseek-chat', // Confirm model name
            'messages' => array(
                array('role' => 'user', 'content' => $prompt)
            ),
            'max_tokens' => $max_tokens,
        );

        $args = array(
            'headers' => $headers,
            'body' => json_encode($body),
            'timeout' => 30,
        );

        $response = wp_remote_post($this->api_url, $args);

        if (is_wp_error($response)) {
            return 'Error: ' . $response->get_error_message();
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body['choices'][0]['message']['content'] ?? 'Error: No content generated.';
    }
}