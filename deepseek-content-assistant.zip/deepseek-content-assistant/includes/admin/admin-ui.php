<?php
class DeepSeek_Admin_UI {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
    }

    public function add_admin_menu() {
        add_menu_page(
            'DeepSeek Assistant',
            'DeepSeek Assistant',
            'manage_options',
            'deepseek-assistant',
            array($this, 'render_ui'),
            'dashicons-edit'
        );
    }

    public function render_ui() {
        ?>
        <div class="wrap">
            <h1>DeepSeek Content Assistant</h1>
    
            <!-- Tabs for navigation -->
            <h2 class="nav-tab-wrapper">
                <a href="?page=deepseek-assistant" class="nav-tab <?php echo empty($_GET['tab']) ? 'nav-tab-active' : ''; ?>">Generate Content</a>
                <a href="?page=deepseek-assistant&tab=settings" class="nav-tab <?php echo isset($_GET['tab']) && $_GET['tab'] === 'settings' ? 'nav-tab-active' : ''; ?>">API Settings</a>
            </h2>
    
            <?php
            // Show the appropriate tab content
            $tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : '';
            switch ($tab) {
                case 'settings':
                    $this->render_settings();
                    break;
                default:
                    $this->render_generator();
                    break;
            }
            ?>
        </div>
        <?php
    }
    
    // Render the content generator UI
    public function render_generator() {
        ?>
        <div id="deepseek-generator">
            <textarea id="deepseek-prompt" rows="5" style="width: 100%;" placeholder="E.g., 'Write a blog post about AI trends in 2024...'"></textarea>
            <button id="generate-content" class="button button-primary">Generate Content</button>
            <div id="deepseek-output" style="margin-top: 20px; padding: 10px; border: 1px solid #ddd;"></div>
        </div>
        <?php
    }
    
    // Render the API settings form
    public function render_settings() {
        ?>
        <form method="post" action="options.php">
            <?php
            settings_fields('deepseek_settings'); // Output security fields
            do_settings_sections('deepseek-assistant'); // Output settings sections
            submit_button('Save Settings');
            ?>
        </form>
        <?php
    }

    public function enqueue_scripts($hook) {
        if ($hook !== 'toplevel_page_deepseek-assistant') return;

        wp_enqueue_script(
            'deepseek-admin-js',
            plugins_url('../assets/js/admin.js', __FILE__),
            array('jquery'),
            '1.0',
            true
        );

        wp_localize_script('deepseek-admin-js', 'deepseek_vars', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('deepseek_nonce'),
        ));
    }
}