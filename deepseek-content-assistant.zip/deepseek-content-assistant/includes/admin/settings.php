<?php
class DeepSeek_Settings {
    public function __construct() {
        add_action('admin_init', array($this, 'register_settings'));
    }

    public function register_settings() {
        // Register the API key setting
        register_setting(
            'deepseek_settings', // Option group
            'deepseek_api_key', // Option name
            array(
                'type' => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            )
        );
    
        // Add the settings section
        add_settings_section(
            'deepseek_api_section', // Section ID
            'API Configuration', // Title
            array($this, 'render_section'), // Callback
            'deepseek-assistant' // Page (matches the menu slug)
        );
    
        // Add the API key field
        add_settings_field(
            'deepseek_api_key', // Field ID
            'DeepSeek API Key', // Label
            array($this, 'render_api_key_field'), // Callback
            'deepseek-assistant', // Page
            'deepseek_api_section' // Section
        );
    }

    public function render_section() {
        echo '<p>Enter your <a href="https://platform.deepseek.com/api-keys" target="_blank">DeepSeek API key</a>.</p>';
    }

    public function render_api_key_field() {
        $api_key = get_option('deepseek_api_key');
        echo '<input type="password" name="deepseek_api_key" value="' . esc_attr($api_key) . '" style="width: 300px;">';
    }
}