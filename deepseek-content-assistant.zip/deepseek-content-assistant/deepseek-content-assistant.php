<?php
/*
Plugin Name: DeepSeek Content Assistant
Description: Integrate DeepSeek AI for WordPress content creation.
Version: 1.0
Author: Your Name
*/

defined('ABSPATH') || exit;

// Load dependencies
require_once plugin_dir_path(__FILE__) . 'includes/class-deepseek-api.php';
require_once plugin_dir_path(__FILE__) . 'includes/admin/admin-ui.php';
require_once plugin_dir_path(__FILE__) . 'includes/admin/settings.php';

// Initialize plugin
add_action('plugins_loaded', 'deepseek_content_assistant_init');
function deepseek_content_assistant_init() {
    if (is_admin()) {
        new DeepSeek_Admin_UI();
        new DeepSeek_Settings();
    }
}

// AJAX handler for content generation
add_action('wp_ajax_deepseek_generate_content', 'handle_deepseek_generate_content');
function handle_deepseek_generate_content() {
    check_ajax_referer('deepseek_nonce', 'nonce');

    $api_key = get_option('deepseek_api_key');
    $prompt = sanitize_text_field($_POST['prompt']);

    if (empty($api_key) || empty($prompt)) {
        wp_send_json_error('Invalid request.');
    }

    $deepseek = new DeepSeek_API($api_key);
    $content = $deepseek->generate_content($prompt);
    wp_send_json_success($content);
}